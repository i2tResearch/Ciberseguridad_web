from __future__ import print_function
import os



#Aqui va la ruta donde se encunetra la carpeta con los archivos (.pcap)
path = '/home/jsvillatech/Documents/Capturas Goodware3/'

files = os.listdir(path)

#Aqui va la ruta donde se va a guardar el txt con todas las rutas de los (.pcap)
file = open('/home/jsvillatech/Documents/testfile.txt', "w")

for name in files:

    file.write(path+name+'\n')

file.close()
